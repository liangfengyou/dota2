-- Generated from template

if CAddonTemplateGameMode == nil then
	CAddonTemplateGameMode = class({})
end

function Precache( context )
	--[[
		Precache things we know we'll use.  Possible file types include (but not limited to):
			PrecacheResource( "model", "*.vmdl", context )
			PrecacheResource( "soundfile", "*.vsndevts", context )
			PrecacheResource( "particle", "*.vpcf", context )
			PrecacheResource( "particle_folder", "particles/folder", context )
	]]
	PrecacheResource( "particle", "particles/units/heroes/hero_sven/sven_spell_storm_bolt.vpcf", context )
	PrecacheResource( "particle_folder", "particles/units/heroes/hero_sven", context )
end

-- Create the game mode when we activate
function Activate()
	GameRules.AddonTemplate = CAddonTemplateGameMode()
	GameRules.AddonTemplate:InitGameMode()
end

function CAddonTemplateGameMode:InitGameMode()
	print( "Template addon is loaded." )
	ListenToGameEvent("game_rules_state_change", Dynamic_Wrap(CAddonTemplateGameMode, "OnGameRulesStateChange"), self)
	GameRules:SetCustomGameSetupAutoLaunchDelay(0)
	GameRules:SetCustomGameSetupRemainingTime(0)
	GameRules:SetHeroSelectPenaltyTime(0)
	GameRules:SetHeroSelectionTime(0)
	GameRules:SetShowcaseTime(0)
	GameRules:SetStrategyTime(0)
	GameRules:GetGameModeEntity():SetThink( "OnThink", self, "GlobalThink", 2 )
end

function CAddonTemplateGameMode:OnGameRulesStateChange(event)
	local state = GameRules:State_Get()
	if state == DOTA_GAMERULES_STATE_STRATEGY_TIME then
		for i = 0, DOTA_MAX_TEAM_PLAYERS - 1 do
			local player = PlayerResource:GetPlayer(i)
			if player and not PlayerResource:HasSelectedHero(i) then
				player:MakeRandomHeroSelection()
			end
		end
		GameRules:GetGameModeEntity():SetAnnouncerDisabled(true)
	end
end

-- Evaluate the state of the game
function CAddonTemplateGameMode:OnThink()
	if GameRules:State_Get() == DOTA_GAMERULES_STATE_GAME_IN_PROGRESS then
		--print( "Template addon script is running." )
	elseif GameRules:State_Get() >= DOTA_GAMERULES_STATE_POST_GAME then
		return nil
	end
	return 1
end