function MySpawnUnit(args)
    local point = args.target_points[1]
    CreateUnitByName( "npc_dota_neutral_centaur_khan", point, false, nil, nil, DOTA_TEAM_NEUTRALS )
end